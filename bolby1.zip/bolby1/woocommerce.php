<?php get_header(); ?>

	<div class="spacer" data-height="70"></div>
		
	<section class="padding-30 shadow-dark bg-white rounded">

        <?php woocommerce_content(); ?>

	</section>

	<div class="spacer" data-height="70"></div>

<?php get_footer(); ?>