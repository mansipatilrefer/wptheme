=== Bolby ===
Author: Jthemes
Author URI: http://themeforest.net/user/jthemes
Requires at least: WordPress 4.7
Tested up to: WordPress 5.1.1
Version: 1.0.2
License: GNU General Public License
License URI: http://themeforest.net/wiki/support/legal-terms/licensing-terms/
Tags: portfolio, agency, minimal, clean, creative, parallax, personal, modern, page-builder

== Description ==

Bolby is a Elementor Page Builder ready theme for WordPress.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Click the 'Upload Theme' button and 'Choose File' -> select 'bolby.zip' and click the 'Install Now' button.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to http://www.pxltheme.com/docs/bolby for a guide on how to customize this theme.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Changelogs ==

= 1.0.2 =
* Service link options added
* Theme required plugin updated
* JS fixed
* CSS fixed

== Changelogs ==

= 1.0.1 =
* Improved dark & light mode switcher
* Added widget area on headers (for adding language switcher)
* Timeline icons are now selectable
* Integrated with WooCommerce

= 1.0 =
* Released

Initial release
