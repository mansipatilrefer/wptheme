<?php if ( is_active_sidebar( 'primary-sidebar' ) ) : ?>
    <div class="sidebar">
        <?php dynamic_sidebar( 'primary-sidebar' ); ?>
    </div>
<?php endif; ?>